-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: plesk_manager
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `v_active_users`
--

DROP TABLE IF EXISTS `v_active_users`;
/*!50001 DROP VIEW IF EXISTS `v_active_users`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_active_users` AS SELECT 
 1 AS `id`,
 1 AS `username`,
 1 AS `email`,
 1 AS `first_name`,
 1 AS `last_name`,
 1 AS `role`,
 1 AS `last_login`,
 1 AS `created_at`,
 1 AS `last_activity`,
 1 AS `activity_status`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_api_usage_stats`
--

DROP TABLE IF EXISTS `v_api_usage_stats`;
/*!50001 DROP VIEW IF EXISTS `v_api_usage_stats`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_api_usage_stats` AS SELECT 
 1 AS `date`,
 1 AS `total_requests`,
 1 AS `unique_users`,
 1 AS `avg_response_time`,
 1 AS `successful_requests`,
 1 AS `error_requests`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_active_users`
--

/*!50001 DROP VIEW IF EXISTS `v_active_users`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`plesk_user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_active_users` AS select `u`.`id` AS `id`,`u`.`username` AS `username`,`u`.`email` AS `email`,`u`.`first_name` AS `first_name`,`u`.`last_name` AS `last_name`,`u`.`role` AS `role`,`u`.`last_login` AS `last_login`,`u`.`created_at` AS `created_at`,coalesce(`al`.`last_activity`,`u`.`last_login`) AS `last_activity`,(case when (`u`.`last_login` > (now() - interval 30 day)) then 'active' when (`u`.`last_login` > (now() - interval 90 day)) then 'inactive' else 'dormant' end) AS `activity_status` from (`users` `u` left join (select `user_activity_log`.`user_id` AS `user_id`,max(`user_activity_log`.`created_at`) AS `last_activity` from `user_activity_log` group by `user_activity_log`.`user_id`) `al` on((`u`.`id` = `al`.`user_id`))) where (`u`.`is_active` = true) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_api_usage_stats`
--

/*!50001 DROP VIEW IF EXISTS `v_api_usage_stats`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`plesk_user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_api_usage_stats` AS select cast(`api_request_log`.`created_at` as date) AS `date`,count(0) AS `total_requests`,count(distinct `api_request_log`.`user_id`) AS `unique_users`,avg(`api_request_log`.`response_time_ms`) AS `avg_response_time`,count((case when ((`api_request_log`.`response_status` >= 200) and (`api_request_log`.`response_status` < 300)) then 1 end)) AS `successful_requests`,count((case when (`api_request_log`.`response_status` >= 400) then 1 end)) AS `error_requests` from `api_request_log` where (`api_request_log`.`created_at` >= (now() - interval 30 day)) group by cast(`api_request_log`.`created_at` as date) order by `date` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-08 15:01:58
