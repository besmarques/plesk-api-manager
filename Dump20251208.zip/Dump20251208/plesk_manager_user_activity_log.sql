-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: plesk_manager
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_activity_log`
--

DROP TABLE IF EXISTS `user_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_activity_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `activity_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `target_resource` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_method` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_data` json DEFAULT NULL,
  `response_status` int DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_activity_type` (`activity_type`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_target_resource` (`target_resource`),
  KEY `idx_ip_address` (`ip_address`),
  KEY `idx_activity_user_type_date` (`user_id`,`activity_type`,`created_at`),
  CONSTRAINT `user_activity_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activity_log`
--

LOCK TABLES `user_activity_log` WRITE;
/*!40000 ALTER TABLE `user_activity_log` DISABLE KEYS */;
INSERT INTO `user_activity_log` VALUES (1,1,'LOGIN','User logged in successfully','auth',NULL,'POST','/api/system/users/login',NULL,NULL,'192.168.1.50','Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0','2025-11-27 16:10:05'),(2,1,'DOMAIN_CREATE','Created new domain','domain','example.com','POST','/api/plesk/domains',NULL,NULL,'192.168.1.50','Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0','2025-11-27 16:10:05'),(8,1,'LOGIN','User logged in',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-11-27 17:23:23'),(9,1,'LOGIN','User logged in',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-11-27 17:24:33'),(10,1,'LOGIN','User logged in',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-11-27 17:27:58'),(11,1,'LOGIN','User logged in',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-11-27 17:28:45'),(12,1,'LOGIN','User logged in',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-11-27 17:30:43'),(13,1,'LOGIN','User logged in',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-11-27 17:32:08'),(14,1,'LOGIN','User logged in',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-11-27 17:34:44'),(15,1,'LOGOUT','User logged out',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-11-27 17:41:49'),(16,1,'LOGIN','User logged in',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-11-27 17:41:54'),(17,1,'LOGOUT','User logged out',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-11-27 17:44:55'),(18,1,'LOGIN','User logged in',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-11-27 17:45:02'),(19,1,'LOGIN','User logged in',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-12-02 14:40:19'),(20,1,'USER_DELETE','Deleted user john_admin (ID: 2)',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-12-02 14:41:33'),(21,1,'USER_UPDATE','Updated user 3',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-12-02 14:41:43'),(22,1,'USER_DELETE','Deleted user alice_manager (ID: 5)',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-12-02 14:42:00'),(23,1,'USER_DELETE','Deleted user bob_viewer (ID: 4)',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-12-02 14:42:02'),(24,1,'USER_DELETE','Deleted user jane_user (ID: 3)',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-12-02 14:42:03'),(25,1,'LOGIN','User logged in',NULL,NULL,NULL,NULL,NULL,NULL,'::1',NULL,'2025-12-02 17:09:25');
/*!40000 ALTER TABLE `user_activity_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-08 15:01:58
